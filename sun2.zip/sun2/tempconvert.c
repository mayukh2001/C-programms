#include<stdio.h>
int main()
{
	float c,f;
	printf("Enter temp in C:\t");
	scanf("%f",&c);
	f=(c*9/5)+32;
	printf("\nTemp in F : %.2f",f);
	return 0;
}
