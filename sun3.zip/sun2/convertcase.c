#include<ctype.h>
#include<stdio.h>
int main()
{
	char c1;
	printf("Enter a Character in Upper Case\t");
	scanf("%c",&c1);
	fflush(stdin);
	c1=tolower(c1);
	printf("\nChar in changed case %c",c1);
	printf("\nEnter a Character in Lower Case\t");
	scanf("%c",&c1);
	c1=toupper(c1);
	printf("\nChar in changed case %c",c1);
}
