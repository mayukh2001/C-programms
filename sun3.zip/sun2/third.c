#include<stdio.h>
int main()
 {
	/*
	 take 
	 2 nos
	 nd print
	 sum
	*/
	int n1,n2,s; //Vaiables
	printf("Enter two Integers:\t");
	scanf("%d%d",&n1,&n2);
	/* Find Sum*/
	s=n1+n2;
	printf("\n%d+%d=%d",n1,n2,s);
	return 0;
}
