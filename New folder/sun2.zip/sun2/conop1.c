#include<stdio.h>
int main()
{
	int n;
	printf("Enter an Integer:\t");
	scanf("%d",&n);
	(n%2==0)? printf("No is Even"): printf("No is Odd");
	return 0;	
}
