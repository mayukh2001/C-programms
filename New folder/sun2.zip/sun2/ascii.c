#include<stdio.h>
int main()
{
	char ch;
	printf("Enter a Character : \t");
	scanf("%c",&ch);
	printf("\nCharacter is %c and ASCII is %d ",ch,ch);
	ch++;
	printf("\nNext Chracter is %c and ASCII is %d",ch,ch);
	return 0;
}
