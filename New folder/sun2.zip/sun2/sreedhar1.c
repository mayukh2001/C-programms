#include<math.h>
#include<stdio.h>
int main()
{
	float a,b,c,temp;
	printf("Enter a:\t");
	scanf("%f",&a);
	printf("Enter b:\t");
	scanf("%f",&b);
	printf("Enter c:\t");
	scanf("%f",&c);
	if(b*b<4*a*c)
	 printf("Roots are Imaginary");
	else if(b*b==4*a*c) 
	 printf("Roots are Equal %f", (-b)/(2*a));
	else
	{
		temp=sqrt(b*b-4*a*c);
		printf("Roots are %f and %f",(-b+temp)/(2*a) , (-b-temp)/(2*a) );
	 } 
	return 0; 
}
