#include<stdio.h>
int main()
{
	int n1,n2,n3;
	printf("Enter 3 Nos\t");
	scanf("%d%d%d",&n1,&n2,&n3);
	if(n1>n2)
	{
		if(n1>n3)
		 printf("1st No is Highest");
		else
		 printf("3rd No is Heighest");
	}
	else
	{
		if(n2>n3)
		  printf("2nd No is Highest");
		else
		 printf("3rd No is Heighest");
	}
	
}
