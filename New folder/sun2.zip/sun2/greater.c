#include<stdio.h>
int main()
{
	int n1,n2;
	printf("Enter an Integer\t");
	scanf("%d",&n1);
	fflush(stdin);
	printf("Enter another Integer\t");
	scanf("%d",&n2);
	if(n1>n2)
	 printf("1st No is Greater than 2nd No");
	else
	{
	 if(n1<n2)	
	  printf("2nd No is Greater than 1st No");
	 else
	  printf("Numbers are Equal") ;
	} 
}
