

#include <stdio.h>
#include <conio.h>
void main()
{


	int n,i,j,l,k=1;
	clrscr();
	printf("Enter Number of Rows : ");
	scanf("%d",&n);

	for(i=n;i>=1;i--)
	{
		for(l=1;l<=n-i;l++)
			printf(" ");

		for(j=1;j<=i;j++)
		{
			printf("%2d ",k);
			k++;
		}

		printf("\n");
	}

	getch();
}
