
#include <stdio.h>
#include <conio.h>
void main()
{


	int n,i,j,k=1;
	clrscr();
	printf("Enter Number of Rows : ");
	scanf("%d",&n);

	for(i=1;i<=n;i++)
	{
		for(k=1;k<=n-i;k++)
			printf(" ");

		for(j=1;j<=i;j++)
			printf("%d ",j);

		printf("\n");
	}

	getch();
}
