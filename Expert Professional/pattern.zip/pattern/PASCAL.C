#include<stdio.h>
#include<conio.h>
void main()
{
int i,j,n,c,k,s;
clrscr();
printf("Enter the limit\t");
scanf("%d",&n);
printf("\n\n");
s=n;
for(i=0;i<=n;i++)
{
c=1;
for(k=s;k>=0;k--)
printf(" ");

s--;
for(j=0;j<=i;j++)
{
printf("%d ",c);
c=(c*(i-j)/(j+1));
}
printf("\n");
}
getch();
}