	/*
	*******   line 1, 0 space, 7 star
	 *****    line 2, 1 space, 5 *
	  ***     line 3, 2 space, 3 *
	   *      line 4, 3 space, 1 *
	*/

	#include<stdio.h>
	#include<conio.h>
	void main()
	{
	 int i,j,n=4;
	 clrscr();
	 printf("\n\tEnter Rows\t");
	 scanf("%d",&n);
	 for(i=n;i>=1;i--)
	 {
	 for(j=1;j<=(n-i);j++)
	 printf(" ");
	 for(j=1;j<=(i*2-1);j++)
	 printf("*");
	 printf("\n");
	 }
	 getch();
	}