
#include <stdio.h>
#include <conio.h>
void main()
{


	int n,i,j,l,k=1;
	clrscr();
	printf("Enter Number of Rows : ");
	scanf("%d",&n);

	for(i=1;i<=n;i++)
	{
		for(l=1;l<=n-i;l++)
			printf(" ");

		for(j=1;j<=i;j++)
		{
			printf("%d ",k);
			k++;
		}

		printf("\n");
	}

	getch();
}
