#include<stdio.h>
struct inventory
{
	int id;
	float price;
};
int main()
{
  struct inventory v[3];	
  int i;
  for(i=0;i<3;i++)
  {
   printf("Material %d: Enter id:\t",i+1);
  scanf("%d",&v[i].id);
  printf("Material %d: Enter Price:\t",i+1);
  scanf("%f",&v[i].price);
  }
  printf("\n");
  for(i=0;i<3;i++)
  printf("\nId: %d and Price: %f",v[i].id,v[i].price);
  return 0;	
}
