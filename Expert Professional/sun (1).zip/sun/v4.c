#include<stdio.h>
int n=0;
void fun()
{
	n++;
}
int main()
{
  printf("%d\n",n);
  n=n+5;
  printf("%d\n",n);
  fun();
  printf("%d\n",n);
	return 0;
}
