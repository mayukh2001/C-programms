#include<stdio.h>
int main()
{
	int yr;
	printf("Enter Year\t");
	scanf("%d",&yr);
	if(yr%4==0)
	{
	  if(yr%100==0)	
	  {
	  	if(yr%400==0)
	  	  printf("Leap Year");
	  	 else
		    printf("Not a Leap Year");
	   }
	   else
	     printf("Leap Year");
	}
	else
	  printf("Not  a Leap Year");
}
