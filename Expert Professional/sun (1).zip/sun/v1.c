#include<stdio.h>
int main()
{
	auto int a;
	printf("Enter Value: ");
	scanf("%d",&a);
	printf("%d",a);
	return 0;
}
