#include<stdio.h>
#define multi(a,b) (a)*(b)
int main()
{
int n1,n2;
 printf("Enter 2 Nos : ");
 scanf("%d%d",&n1,&n2);
 printf("\nResult %d",multi(n1+10,n2+10));      
 return 0;
}
