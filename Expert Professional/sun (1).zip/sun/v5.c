#include<stdio.h>
void fun()
{
  extern int n;
	n++;
}

int main()
{
  extern int n;
  printf("%d\n",n);
  n=n+5;
  printf("%d\n",n);
  fun();
  printf("%d\n",n);
	return 0;
}
int n=0;
