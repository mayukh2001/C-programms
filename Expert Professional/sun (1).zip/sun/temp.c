#include<stdio.h>
int main()
{
	float c,f;
	printf("Enter Temp in Centigrade: \t");
	scanf("%f",&c);
	f=(9*c/5)+32;
	printf("%.2f",f);
	return 0;
}
