#include<stdio.h>
#define len 5
int main()
{
	int ar[len],i, *p;
	p=ar;
	for(i=0;i<len;i++)
	{
		printf("Enter Value %d:  ",i+1);
		scanf("%d",p++);						
	}	
	p=ar;
	for(i=0;i<len;i++)
	{
	 *p=*p+10;
	 p++;
	}
	printf("\n");
	p=ar;
	for(i=0;i<len;i++)
	{
		printf("%d\t",*(p));
		p++;
  	}
return 0;	
}
