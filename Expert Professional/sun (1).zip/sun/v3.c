#include<stdio.h>
int fun()
{
	static int i=0;
	i++;
	return i;
}
int main()
{
	int n;
	for(n=1;n<=5;n++)
	 printf("%d\n", fun());
	
	return 0;
}
