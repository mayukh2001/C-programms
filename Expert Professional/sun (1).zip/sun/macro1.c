#include<stdio.h>
#define sum(a,b) a+b
int main()
{
int n1,n2;
 printf("Enter 2 Nos : ");
 scanf("%d%d",&n1,&n2);
 printf("\nResult %d",sum(n1,n2));
 return 0;
}
