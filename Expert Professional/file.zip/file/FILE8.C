#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct  emp
{
 char name[40];
int id;
} ;

main()
{
FILE *p;
char str[40];
struct emp e1;
p=fopen("emp.rec","rb");
if (p==NULL)
 printf("\n\tCan't OPen File");
else
{
while(fread(&e1,sizeof(struct emp),1,p)==1)
{
 printf("\n\tName : %s",e1.name);
 printf("\n\tID : %d",e1.id);
}
}
fclose(p);
return 0;
}
