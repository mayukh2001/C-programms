#include<stdio.h>
#include<conio.h>
 main()
{
FILE *p;
char ch;
p=fopen("text1.txt","w");
if (p==NULL)
printf("Error : File Can not be created");
else
{
printf("Enter a Line. Then Press Enter\n");
while((ch =  getche()) !='\r')
 putc(ch,p);
 }
fclose(p);
return 0;
}
