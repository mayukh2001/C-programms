#include<stdio.h>
#include<string.h>
 main()
{
FILE *p;
char str[50];
p=fopen("text2.txt","w");
if (p==NULL)
printf("Error : File NOT Created");
else
{
 printf ( "\nEnter a few lines of text: Press enter in Blank Line to Stop\n" ) ;
while(strlen(gets(str))>0)
{
 fputs(str,p);
 fputs("\n",p);
 }
 }
fclose(p);
return 0;
}
