#include<stdio.h>
#include<conio.h>
main()
{
FILE *p;
 int ch;
p=fopen("text1.txt","r");
if (p==NULL)
printf("Error : File not Found");
else
{
printf("Content of the File\n");
while((ch =getc(p)) !=EOF)
 printf("%c",ch);
 }
fclose(p);
return 0;
}
