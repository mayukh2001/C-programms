#include<stdio.h>
#include<conio.h>
 main()
{
FILE *p;
char name[50],choice; int id;
p=fopen("emp.txt","w");
do
{
 fflush(stdin);
 printf("\n\tType Name\t");
 scanf("%s",name);
 fflush(stdin);
 printf("\n\tType ID\t");
 scanf("%d",&id);
 fprintf(p,"%s%d",name,id);
 fprintf(p,"\n");
 printf("\n\tEnter another ? 'y' to Continue\t");
 choice=getche();
 }while(choice =='y');
fclose(p);
return 0;
}
