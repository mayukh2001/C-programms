#include<stdio.h>
#include<conio.h>

main()
{
FILE *p;
char str[50];
p=fopen("text2.txt","r");
if (p==NULL)
printf("NOT Found");
else
{
while(fgets(str,49,p) !=NULL)
{
 printf("%s",str);
 }
 }
fclose(p);
//getch();
}
