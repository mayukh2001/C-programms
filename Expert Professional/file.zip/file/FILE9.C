#include<stdio.h>
#include<conio.h>
main( )
{
FILE *fp ;
char ch ;
fp = fopen ( "FILE9.C", "r" ) ;
if (fp==NULL)
 printf("\n\tCan't OPen File");
else
{
while ( 1 )
{
ch = fgetc ( fp ) ;
if ( ch == EOF )
break ;
printf ( "%c", ch ) ;
}
}
fclose ( fp ) ;
}
