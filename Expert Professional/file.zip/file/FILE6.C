#include<stdio.h>
#include<conio.h>
#include<string.h>
main()
{
FILE *p;
char name[50];
int id;
p=fopen("emp.txt","r");
while(fscanf(p,"%s%d",name,&id) !=EOF)
{
 printf("\n\t%s \t%d",name,id);
}
fclose(p);
return 0;
}
