#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct  emp
{
 char name[40];
int id;
} ;

 main()
{
FILE *p;
char str[40];
struct emp e1;
p=fopen("emp.rec","wb");
if (p==NULL)
 printf("\n\tCan't Open File");
else
{
do
{ 
 printf("\n\tEnter Name\t");
 gets(e1.name);
 fflush(stdin);
 printf("\n\tEnter ID\t");
 scanf("%d",&e1.id);
 fflush(stdin);
fwrite(&e1,sizeof(struct emp),1,p);
printf("\n\tAdd another emp (y/n)?\t");
} while(getche()=='y');
}
fclose(p);
return 0;
}
