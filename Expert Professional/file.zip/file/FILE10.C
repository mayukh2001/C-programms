#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
main( )
{
FILE *fs, *ft ;
char ch ;
fs = fopen ( "FILE10.c", "r" ) ;
if ( fs == NULL )
{
puts ( "Cannot open source file" ) ;
exit(0) ;
}
ft = fopen ( "copyfile.txt", "w" ) ;
if ( ft == NULL )
{
puts ( "Cannot open target file" ) ;
fclose (fs) ;
exit(0) ;
}
while ( 1 )
{
ch = fgetc ( fs ) ;
if ( ch == EOF )
break ;
else
fputc ( ch, ft ) ;
}
fclose ( fs ) ;
fclose ( ft ) ;
} 
