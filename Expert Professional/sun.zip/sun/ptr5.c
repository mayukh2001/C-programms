#include<stdio.h>
#define len 5
int main()
{
	int ar[len],i;
	for(i=0;i<len;i++)
	{
		printf("Enter Value %d:  ",i+1);
		scanf("%d",ar+i);							//scanf("%d",&ar[i]);
	}	
	for(i=0;i<len;i++)
	{
	*(ar+i)=*(ar+i)+10; 						//ar[i]=ar[i]+10;
	}
	printf("\n");
	for(i=0;i<len;i++)
		printf("%d\t",*(ar+i));
return 0;	
}
