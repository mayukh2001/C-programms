#include<stdio.h>
void swap(int *, int *);

int main()
{
	int a, b;
	printf("Enter 2 Integers:\t");
	scanf("%d%d",&a,&b);			
	printf("\nValues before Swapping : %d  and %d",a,b);
	swap(&a,&b);
	printf("\nValues After Swapping : %d  and %d",a,b);
	return 0;
}
void swap(int *p1, int *p2)
{
 int temp;
 temp=*p1;
 *p1=*p2;
 *p2=temp; 	
}
