#include<stdio.h>
#include<stdlib.h>
int main()
{
	int *p;
	//p=calloc(sizeof(int));
	p=(int *)calloc(1,sizeof(int));
	printf("Enter an Integer value:\t");
	scanf("%d",p);
	printf("Value is : %d",*p);
	return 0;
}

