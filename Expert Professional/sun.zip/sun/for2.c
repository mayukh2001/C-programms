#include<stdio.h>
int main()
{
	int i=1;
	/*
	for(;i<=10;i++ )
	{
		printf("%d\t",i);
	}
	*/
	for(;i<=10; )
	{
		printf("%d\t",i);
		i++;
	}	
return 0;	
}

