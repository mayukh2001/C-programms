#include<stdio.h>
int main()
{
	register int a;
	int b;
	printf("Enter Value: ");
	scanf("%d",&b);
	a=b;
	a++;
	printf("%d",a);
	return 0;
}
