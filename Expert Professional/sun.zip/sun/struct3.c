#include<stdio.h>
struct inventory
{
	int id;
	float price;
};
struct inventory v1;
int main()
{
  //struct inventory v1;	
  printf("Enter id:\t");
  scanf("%d",&v1.id);
  printf("Enter Price:\t");
  scanf("%f",&v1.price);
  printf("\nId: %d and Price: %f",v1.id,v1.price);
  return 0;	
}
