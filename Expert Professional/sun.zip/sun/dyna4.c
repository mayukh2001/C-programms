#include<stdio.h>
struct inventory
{
	int id;
	float price;
};
struct inventory v1, *p;
int main()
{
  p=&v1;	
  printf("Enter id:\t");
  scanf("%d",&p->id);
  printf("Enter Price:\t");
  scanf("%f",&p->price);
  printf("\nId: %d and Price: %f",p->id,p->price);
  return 0;	
}
