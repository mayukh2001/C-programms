#include<stdio.h>
#include<stdlib.h>
int main()
{
	int n;
	printf("Space Rqd for Integer : %d", sizeof(int));
	printf("\nSpace Rqd for Integer : %d", sizeof(n));
	printf("\nSpace Rqd for Float : %d", sizeof(float));
	return 0;
}
