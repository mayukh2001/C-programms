#include<stdio.h>
int main()
{
	char name[50];
	printf("Enter Your Name :\t");
	scanf("%s",&name);
	printf("Hello %s",name);
	return 0;
}
