#include<stdio.h>
struct inventory
{
	int id;
	float price;
};
struct inventory *p;
int main()
{
  p=malloc(sizeof(struct inventory));	
  printf("Enter id:\t");
  scanf("%d",&p->id);
  printf("Enter Price:\t");
  scanf("%f",&p->price);
  printf("\nId: %d and Price: %f",p->id,p->price);
  return 0;	
}
