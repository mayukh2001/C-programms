#include<stdio.h>
#include<stdlib.h>
int main()
{
	int *p;
	//p=malloc(sizeof(int));
	p=(int *)malloc(sizeof(int));
	printf("Enter an Integer value:\t");
	scanf("%d",p);
	printf("Value is : %d",*p);
	return 0;
}
