#include<stdio.h>
void accept(int *,int);
void disp (int[],int);
int main()
{
	int ar[5];
    accept(ar,5)	;
    disp(ar,5);
    return 0;
}
	
void accept(int *p, int len)
{
	int i;
	for(i=0;i<len;i++)
	{
		printf("Enter Value %d:  ",i+1);
		scanf("%d",p++);						
	}	
}

void disp(int ar[],int len)
{
	int i;
	printf("\n");
	for(i=0;i<len;i++)
	{
		printf("%d\t",ar[i]);
  	}	
}
