//Write a function for mutliply(n1, n2), where n1 and n2 are both
// positive integers, but you can only use the + or - operators.
#include<stdio.h>
int multi_rec (int,int);
int main()
{
int n1,n2;
printf("Enter 1st No\t");
scanf("%d",&n1);
printf("Enter 2nd No\t");
scanf("%d",&n2);
printf("\nResult = %d",multi_rec(n1,n2));
return 0;
}
int multi_rec(int n1,int n2)
{
  if(n1 != 0)
   return n2+multi_rec(n1-1,n2);
   else
    return 0;
}
