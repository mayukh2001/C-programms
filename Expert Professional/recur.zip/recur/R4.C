//Calculate power using recursive function
#include<stdio.h>
long pow_rec (int,int);
int main()
{
int n,p;
printf("Enter No\t");
scanf("%d",&n);
printf("Enter Power\t");
scanf("%d",&p);
printf("\n%d ^ %d = %ld",n,p,pow_rec(n,p));
return 0;
}

long pow_rec(int n, int p)
{
if (p ==0)
 return 1;
else
 return n * pow_rec(n, p-1);
}
