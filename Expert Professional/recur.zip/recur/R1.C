//sum of n natural numbers
#include<stdio.h>
int sum_rec (int);
int main()
{
int n;
printf("Enter Limit\t");
scanf("%d",&n);
printf("\nResult = %d",sum_rec(n));
return 0;
}
int sum_rec(int n)
{
  if(n != 0)
   return n+sum_rec(n-1);
  else
  return 0;
}
