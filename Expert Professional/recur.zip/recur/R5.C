//Calculate Sum of all digits of an Integer using recursive function
#include<stdio.h>
int dig_rec (int);
int main()
{
int n;
printf("Enter No\t");
scanf("%d",&n);
printf("\nSum of all the digits of %d is %d",n,dig_rec(n));
return 0;
}

int dig_rec(int n)
{
if (n !=0)
 return n % 10 + dig_rec(n/10);
 else
return 0;
}
