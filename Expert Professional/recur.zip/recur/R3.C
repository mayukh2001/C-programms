//Calculate GCD or HCF using recursive function
#include<stdio.h>
int gcd_rec (int,int);
int main()
{
int n1,n2;
printf("Enter 1st No\t");
scanf("%d",&n1);
printf("Enter 2nd No\t");
scanf("%d",&n2);
printf("\nGCD of %d and %d = %d",n1,n2,gcd_rec(n1,n2));
return 0;
}

int gcd_rec(int n1, int n2)
{
if (n2!=0)
return gcd_rec(n2, n1%n2);
else
return n1;
}
