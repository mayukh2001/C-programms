// BUBBLE SORT Using C
#include<stdio.h>
#include<conio.h>
#define max 5
void bsort(int *,int);
int main()
{
	int i,a[max];
	printf("Enter %d Numbers : ",max);
	for(i=0;i<max;i++)
	{
	fflush(stdin);
	printf("\nenter no %d:\t",i+1);
	scanf("%d",&a[i]);
	fflush(stdin);
	}
	bsort(a,max);
	printf("\nThe Elements in Sorted Form ");
	for(i=0;i<max;i++)
	{
	printf("\n%d",a[i]);
	}
	return 0;
       }
    
       void bsort(int *a,int n)
       {
       int temp,i,j; int t;
       for(i=1;i<n;i++)
       {
       for(j=0;j<n-i;j++)
       {
       if(a[j]>a[j+1])
       {
       temp=a[j];
       a[j]=a[j+1];
       a[j+1]=temp;
       }
       }
	
	//////////////////////////////
	printf("\n");
	for(t=0;t<n;t++)
	 printf("%d\t",a[t]);
	/////////////////////// 
       }
       }




