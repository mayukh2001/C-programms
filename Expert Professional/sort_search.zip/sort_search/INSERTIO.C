/*insertion sort*/
#include<stdio.h>
 int main()
{   int x[5],i,j,k,tmp;
    for(i=0;i<5;i++)
	scanf("%d",&x[i]);
    printf("\n insertion..");
    for(i=0;i<5;i++)
	printf(" %d ",x[i]);
    for(i=1;i<=4;i++)
    {    for(j=0;j<i;j++)
	 {  if(x[j]>x[i])
	    {   tmp=x[j];
		x[j]=x[i];
		for(k=i;k>j;k--)
		{ x[k]=x[k-1];}
		x[k+1]=tmp;
	    }
	 }
    }
   printf("\n insertion sort..");
    for(i=0;i<5;i++)
	printf(" %d",x[i]);
    return 0;
}
