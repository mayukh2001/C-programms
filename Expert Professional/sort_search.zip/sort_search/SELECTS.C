/* SELECTION SORT */

# include<stdio.h>
# include<conio.h>
#define max 50
void selection_sort(int , int *);

int main()
{
	int number, list[max];
	int i;
	printf("Input the number of elements in the list: (max 50)\t");
	scanf("%d", &number);
	fflush(stdin);
	printf("\nNumber  of elements in the list is: %d", number);
	printf("\nInput the elements of the list");
	for(i = 0 ; i < number ; i++)
		{
		  printf("\nEnter Element %d\t",i+1);
		  scanf("%d", &list[i]);
		  fflush(stdin);
		}
	selection_sort( number, list);
	printf("\nSorted list is as follows :");
	for( i = 0 ; i < number; i++)
		printf("\n%d", list[i]);

return 0;
}

/* Definition of function */

void selection_sort(int n, int a[])
{
	int min ;
	int k, i; int t;

	for(i = 0; i< n - 1 ; i++)
	{
		min = i ;
		for(k = i + 1; k < n ; k ++)
		{
			if(a[min] > a[k])
				min = k ;
		}
		if( min != i)
		{
			int temp = a[i];
			a[i] = a[min];
			a[min] = temp ;
		}
	   /////////////////////////////////
	   printf("\n");
	  for(t=0;t<n;t++)
	  printf("\t%d",a[t]);
	  /////////////////////////////// 
	}

}
