#include<stdio.h>
int main()
{
	int a, b;
	printf("Enter an Integer:\t");
	scanf("%d",&a);
	//a++;
	//++a;
	printf("\nValue is %d",a++);
	printf("\nValue is %d",a);
	printf("\nEnter another Integer:\t");
	scanf("%d",&b);
	printf("\nValue is %d",++b);
	printf("\nValue is %d",b);
	printf("\n%u, %u",&a, &b);
}
