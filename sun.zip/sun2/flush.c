#include<stdio.h>
int main()
{
	int n; char ch;
	printf("Enter an Integer : \t");
	scanf("%d",&n);
	fflush(stdin);
	printf("\nEnter a Character : \t");
	scanf("%c",&ch);
	printf("\nNo is %d and Character is %c",n,ch);
	return 0;
}
