#include<stdio.h>
int main()
{
	int n1,n2,s;
	printf("Enter an Integer:\t");
	scanf("%d",&n1);
	printf("Enter another Integer\t");
	scanf("%d",&n2);
	s=n1+n2;
	printf("\n%d",s);
	return 0;
}
