#include<stdio.h>
#include<math.h>
int main()
{
	float p,r,y,a;
	printf("Enter Principal Amount\t");
	scanf("%f",&p);
	printf("Enter rate of Interest\t");
	scanf("%f",&r);
	printf("Enter No of Years\t");
	scanf("%f",&y);
	a=p * pow( (1+r/100) , y);
	printf("Final Amount %f",a);
	return 0;
}
