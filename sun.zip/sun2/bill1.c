#include<stdio.h>
int main()
{
	int u;
	float uc,ec,gc,sc,tax,subtot,tot,rent=150;
	printf("Enter Units Consumed:\t");
	scanf("%d",&u);
	if(u<=100)
	 uc=u*.5;
	else
	{ 
	if(u<=200) 
	 uc=100*.5 + (u-100)*.75;
	else
	{
		if(u<=400)
		 uc=100*.5+100*.75+(u-200)*1;
		else
		 {
		 	if(u<=500)
		 	 uc=100*.5+100*.75+200+(u-400)*1.25;
		 	else
			 uc=100*.5+100*.75+200+100*1.25+(u-500) *1.5;
		  } 
	 } 
    }
	if(uc>300)
	 ec=uc*.0925;
	else
	 ec=uc*.0375 ;
	gc=uc +ec;
	
	if(gc>350)
	 sc=gc*.0925;
	else
	 sc=gc*.0125;
	subtot=gc+sc+rent;  
	tax=subtot*.125;
	tot=subtot+tax;
	printf("\nFinal Bill is %.2f",tot);
	return 0;
}
